@echo off
cd /d "%~dp0"
start "" "%~dp0reminder_easy.html"
